===============================
Abstraction - Music Loop Bundle
===============================

This ZIP package is a download from https://tallbeard.itch.io/music-loop-bundle

==== PLEASE NOTE ====
MP3 files will often NOT loop seamlessly. You will notice a very short gap when the song loops. This is due to the nature of the MP3 file format and is often difficult to overcome. It is recommended to use these songs as OGG files.
=====================

If you use any of these songs, please let me know! I'd love to see the game you made. Also, I maintain an itch collection (https://itch.io/c/1406541/games-ive-contributed-music-to) featuring all the games where the music is used 🥰

It's not required, but if you'd like to credit me, please use the artist name "Abstraction" and link to either this page (https://tallbeard.itch.io/music-loop-bundle) or the Abstraction homepage (https://abstractionmusic.com/). Thank you!

While these songs are listed as pay-what-you-want, if you do plan on making money off your project (either through ads, microtransactions, or direct sales), please consider subscribing to my Patreon (https://patreon.com/ben_burnes) for access to hundreds more songs and to support the creation of more music.

-----

Here are a few other places on the Internet where you can find me:

Website:    abstractionmusic.com
Bandcamp:   abstractionmusic.bandcamp.com
Patreon:    patreon.com/ben_burnes
YouTube:    youtube.com/ben_burnes
Spotify:    abstraction.rocks

You can get in contact with me directly through Twitter @ben_burnes, I love to chat with new people!

<3
- Benjamin